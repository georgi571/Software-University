create definer = root@localhost trigger trg_log_balance_change
    after update
    on accounts
    for each row
BEGIN
    IF OLD.balance <> NEW.balance THEN
        INSERT INTO logs (account_id, old_sum, new_sum)
        VALUES (NEW.id, OLD.balance, NEW.balance);
    END IF;
END;

