create
    definer = root@localhost procedure usp_deposit_money(IN account_id int, IN money_amount decimal(19, 4))
BEGIN
    START TRANSACTION;
    IF ((SELECT COUNT(*) FROM accounts WHERE id = 1) <> 1 OR money_amount < 0) THEN
        ROLLBACK;
    ELSE
        UPDATE accounts SET balance = balance + money_amount WHERE id = account_id;
    END IF;
END;

