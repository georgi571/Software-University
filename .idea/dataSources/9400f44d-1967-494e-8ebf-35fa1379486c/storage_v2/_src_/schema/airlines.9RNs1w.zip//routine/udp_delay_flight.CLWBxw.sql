create
    definer = root@localhost procedure udp_delay_flight(IN code varchar(50))
BEGIN
    UPDATE airlines.flights AS f
    SET
        f.has_delay = 1,
        f.departure = DATE_ADD(f.departure, INTERVAL 30 MINUTE)
    WHERE f.flight_code = `code`;
END;

