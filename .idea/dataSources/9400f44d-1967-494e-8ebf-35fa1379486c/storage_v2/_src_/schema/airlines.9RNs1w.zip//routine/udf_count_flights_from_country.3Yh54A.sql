create
    definer = root@localhost function udf_count_flights_from_country(country varchar(50)) returns int deterministic
BEGIN
    DECLARE total_flight_from_country INT;

    SELECT
        COUNT(*) INTO total_flight_from_country
    FROM airlines.flights AS f
             JOIN airlines.countries AS c ON c.id = f.departure_country
    WHERE c.name = `country`;

    RETURN total_flight_from_country;
END;

