create definer = root@localhost view v_employees_hired_after_2000 as
select `soft_uni3`.`employees`.`first_name` AS `first_name`, `soft_uni3`.`employees`.`last_name` AS `last_name`
from `soft_uni3`.`employees`
where (year(`soft_uni3`.`employees`.`hire_date`) > 2000);

