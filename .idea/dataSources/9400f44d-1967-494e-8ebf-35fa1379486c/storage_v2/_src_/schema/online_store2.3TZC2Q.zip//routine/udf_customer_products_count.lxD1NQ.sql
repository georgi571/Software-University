create
    definer = root@localhost function udf_customer_products_count(name varchar(30)) returns int deterministic
BEGIN
    DECLARE total_number_of_product_a_customer_order INT;

    SELECT
        COUNT(*) INTO total_number_of_product_a_customer_order
    FROM online_store2.orders AS o
             LEFT JOIN online_store2.customers c on c.id = o.customer_id
             LEFT JOIN online_store2.orders_products op on o.id = op.order_id
    WHERE c.first_name = `name`;

    RETURN total_number_of_product_a_customer_order;
END;

