create definer = root@localhost view v_employees_job_titles as
select concat_ws(' ', `soft_uni2`.`employees`.`first_name`, `soft_uni2`.`employees`.`middle_name`,
                 `soft_uni2`.`employees`.`last_name`) AS `full_name`,
       `soft_uni2`.`employees`.`job_title`            AS `job_title`
from `soft_uni2`.`employees`;

