create
    definer = root@localhost function udf_average_lesson_price_by_city(name varchar(40)) returns decimal(19, 2)
    deterministic
BEGIN
    DECLARE average_lesson_price DECIMAL(19, 2);

    SELECT AVG(ds.average_lesson_price) INTO average_lesson_price
    FROM go_roadie.driving_schools AS ds
             JOIN go_roadie.cities AS c ON c.id = ds.city_id
    WHERE c.name = `name`;

    RETURN average_lesson_price;
END;

