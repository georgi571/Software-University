create
    definer = root@localhost function udf_users_photos_count(username varchar(30)) returns int deterministic
BEGIN
    DECLARE number_of_photos_that_user_has_upload INT;

    SELECT
         COUNT(up.photo_id) INTO number_of_photos_that_user_has_upload
    FROM instd.users AS u
        LEFT JOIN instd.users_photos up on u.id = up.user_id
    WHERE u.username = `username`
    GROUP BY u.id;

    RETURN number_of_photos_that_user_has_upload;
END;

