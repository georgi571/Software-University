create
    definer = root@localhost procedure udp_modify_user(IN address varchar(30), IN town varchar(30))
BEGIN

    UPDATE instd.users AS u
        JOIN instd.addresses a on u.id = a.user_id
    SET u.age = u.age + 10
    WHERE a.address = `address` AND a.town = `town`;
END;

