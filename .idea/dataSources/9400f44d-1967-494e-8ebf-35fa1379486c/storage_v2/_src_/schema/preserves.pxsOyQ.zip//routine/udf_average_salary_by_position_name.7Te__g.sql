create
    definer = root@localhost function udf_average_salary_by_position_name(name varchar(40)) returns decimal(19, 2)
    deterministic
BEGIN
    DECLARE average_salary_by_position DECIMAL(19, 2);

    SELECT AVG(w.salary) INTO average_salary_by_position
    FROM preserves.positions AS p
        JOIN preserves.workers w on p.id = w.position_id
    WHERE p.name = `name`;

    RETURN average_salary_by_position;
END;

