create
    definer = root@localhost function ufn_is_word_comprised(set_of_letters varchar(50), word varchar(50)) returns tinyint
    deterministic
BEGIN
    RETURN (
        SELECT word REGEXP CONCAT('^[', set_of_letters, ']+$')
    );
END;

